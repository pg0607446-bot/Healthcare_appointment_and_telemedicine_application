# CarePath: Line-by-Line Code Explanation (Hinglish)

File: `carepath.html`. Isme 3 hisse hain: **HTML** (structure), **CSS** (design), **JavaScript** (logic + AI). Sir ko pehle ye flow batao:

> Patient symptoms likhta hai → AI specialty aur urgency batata hai → doctor list aati hai → slot book hota hai → appointment me "Join call" → video consultation.

---

## PART 1: HTML (structure)

```html
<!DOCTYPE html>                      <!-- browser ko batata hai ye HTML5 page hai -->
<html lang="en">                     <!-- page ki language English -->
<head>                               <!-- yahan page ki settings hoti hain, screen par nahi dikhti -->
<meta charset="utf-8">               <!-- har tarah ke characters (₹, ★) sahi dikhane ke liye -->
<meta name="viewport" content="width=device-width, initial-scale=1">
                                     <!-- mobile par page sahi size me dikhe (responsive) -->
<title>CarePath ...</title>          <!-- browser tab ka naam -->
<link href="https://fonts.googleapis.com/...">   <!-- Google se sundar fonts load karta hai -->
<style> ... </style>                 <!-- poora CSS yahan hai -->
</head>
<body>                               <!-- yahan se screen par dikhne wala content -->
```

```html
<header>                             <!-- upar ki bar -->
  <div class="logo">Care<i>Path</i></div>     <!-- logo; <i> se "Path" ka alag color -->
  <nav id="nav">                              <!-- menu buttons ka dibba -->
    <button data-v="home" class="on">AI triage</button>
    <button data-v="docs">Doctors</button>
    <button data-v="appts">My appointments</button>
    <button data-v="room">Consultation</button>
  </nav>
</header>
```
- `data-v="home"` = button ka hidden naam. JavaScript isse padhkar decide karti hai kaunsa page dikhana hai.
- `class="on"` = jo button abhi selected hai.

```html
<section id="v-home"> ... </section>      <!-- Page 1: AI triage -->
<section id="v-docs" class="hide"> ...    <!-- Page 2: Doctors (shuru me hidden) -->
<section id="v-appts" class="hide"> ...   <!-- Page 3: Appointments (hidden) -->
<section id="v-room" class="hide"> ...    <!-- Page 4: Video room (hidden) -->
```
Ye **single page app** hai. 4 sections hain, aur JS ek time par sirf ek ko dikhata hai (baaki `hide` class se chhup jate hain).

```html
<textarea id="sym" placeholder="..."></textarea>      <!-- symptoms likhne ka box -->
<button class="btn" id="go">Analyze symptoms</button> <!-- AI chalane ka button -->
<div id="result" class="panel hide"></div>            <!-- AI ka result yahan aayega -->
```
`id` ek unique naam hai; JS `document.getElementById("sym")` se isi box tak pahunchti hai.

```html
<video id="vid" autoplay muted playsinline></video>   <!-- camera ki live video -->
```
- `autoplay` = apne aap chale, `muted` = apni hi awaaz echo na ho, `playsinline` = iPhone me full screen na ho.

```html
<script> ... </script>     <!-- poora JavaScript yahan hai, body ke end me -->
```

---

## PART 2: CSS (design: sirf important lines)

```css
:root{ --bg:#f2f7f6; --teal:#0e7c7b; --amber:#f2a93b; ... }
```
`:root` me **colors ke variables** rakhe hain. Baad me `var(--teal)` likhne se wahi color lagta hai. Ek jagah badlo to poori site badal jati hai.

```css
@media(prefers-color-scheme:dark){ ... }
```
Agar user ke phone/laptop me **dark mode** on hai, to dark colors lag jate hain.

```css
*{box-sizing:border-box}
```
Padding aur border width ke andar hi count hote hain, layout nahi bigadta.

```css
.hero{display:grid; grid-template-columns:1.1fr 1fr; gap:28px}
@media(max-width:760px){ .hero{grid-template-columns:1fr} }
```
Computer par 2 columns (text | box). Mobile (760px se chhoti screen) par 1 column. Yehi **responsive design** hai.

```css
.panel{ background:var(--card); border:1px solid var(--line); border-radius:14px; padding:20px }
```
Safed card: border, gol corners (`border-radius`) aur andar ki jagah (`padding`).

```css
.bar span{ display:block; height:100%; background:var(--teal); transition:width .6s }
```
Probability bar. `transition` se bar dheere dheere bharti hai (animation).

```css
.hide{ display:none }
```
Is class wala element screen se gayab. JS isi ko lagakar/hatakar pages badalti hai.

```css
.slot[disabled]{ opacity:.35; cursor:not-allowed }
```
Jo slot book ho chuka hai wo dhundhla aur click ke liye band dikhta hai.

---

## PART 3: JavaScript (sabse important, line by line)

### 3.1 AI/ML triage model

```js
const SPECIALTIES = {
 "General Physician": { fever:3, cold:3, cough:2, "body pain":2, ... },
 "Cardiologist":      { "chest pain":5, palpitations:4, ... },
 ...
};
```
- Ye hamare model ka **knowledge** hai. Har specialty ke saamne symptoms aur unka **weight** (1 se 5).
- Weight jitna zyada, symptom us specialty se utna zyada juda hai. Jaise "chest pain" ka weight Cardiologist me 5 hai, kyunki ye heart ka bada sanket hai.
- Real ML me ye weights data se **train** hote hain. Yahan hum ne haath se rakhe hain (prototype).

```js
const RED_FLAGS = ["chest pain","shortness of breath","seizure", ...];
const MID_FLAGS = ["high fever","vomiting","palpitations", ...];
```
Khatarnak shabdon ki list. Red flag mila to **High urgency**, mid flag mila to **Medium**.

```js
const norm = s => s.toLowerCase().replace(/[^a-z\s]/g, " ");
```
**Text cleaning (preprocessing)**: sab kuch chhote letters me aur symbols hata dete hain, taaki "Fever!!" aur "fever" same samjhe jayein. (`/[^a-z\s]/g` = letters aur space ke alawa sab.)

```js
function triage(text){
  const t = " " + norm(text) + " ";     // saaf kiya hua text, dono taraf space
  const raw = {};  let hits = [];       // raw = har specialty ka score, hits = mile huye symptoms
```

```js
  for (const [sp, w] of Object.entries(SPECIALTIES)){
```
Har specialty par ek-ek karke chalo. `sp` = naam (Cardiologist), `w` = uske symptoms ke weights.

```js
    let s = 0.15;     // prior: shuruaati chhota score, taaki kisi ka score zero na ho
    for (const [k, v] of Object.entries(w))
      if (t.includes(" "+k+" ") || t.includes(k)) { s += v; hits.push(k) }
```
Us specialty ke har symptom `k` ko dekho. Agar user ke text me wo mila, to uska weight `v` score me **jodo**, aur symptom ko `hits` me yaad rakho.

```js
    raw[sp] = s;    // is specialty ka final score
  }
```

```js
  const exp = Object.fromEntries(
    Object.entries(raw).map(([k,v]) => [k, Math.exp(v/1.6)])
  );
  const tot = Object.values(exp).reduce((a,b) => a+b, 0);
  const probs = Object.entries(exp)
      .map(([k,v]) => ({ sp:k, p:v/tot }))
      .sort((a,b) => b.p - a.p);
```
Yahan **softmax** hai (ML ka famous concept):
1. `Math.exp(v/1.6)`: score ko exponential me badla. Isse bada score aur bada ho jata hai. 1.6 "temperature" hai.
2. `tot` = sabka total.
3. `v/tot` = har specialty ka hissa. Sab milakar **100%** hota hai, yani probability.
4. `.sort(...)` = sabse zyada probability wali upar.

```js
  let urgency = "low";
  if (RED_FLAGS.some(f => t.includes(f))) urgency = "high";
  else if (MID_FLAGS.some(f => t.includes(f)) || /(3|4|5|6|7) days|week/.test(t)) urgency = "mid";
```
- `some()` = list me se koi bhi ek mil jaye.
- Red flag mila → high. Nahi to mid flag mila **ya** "3 days / week" jaisa lamba samay likha hai → mid. Warna low.

```js
  return { probs: probs.slice(0,3), urgency, matched: [...new Set(hits)], found: hits.length>0 };
}
```
Top 3 specialties, urgency, mile huye symptoms (`Set` duplicates hatata hai), aur `found` = kuch mila ya nahi.

### 3.2 Data aur storage

```js
const DOCTORS = [ {id:1, name:"Dr. Ananya Sharma", sp:"General Physician", exp:12, fee:400, rating:4.8}, ... ];
const TIMES = ["10:00","10:30", ...];
```
Dummy doctors ki list aur slot ke time. Real project me ye **database** se aayega.

```js
let appts = [];
try { appts = JSON.parse(localStorage.getItem("cp_appts") || "[]") } catch(e) {}
const save = () => { try { localStorage.setItem("cp_appts", JSON.stringify(appts)) } catch(e) {} };
```
- `localStorage` = browser ki chhoti memory. Page refresh karne par bhi appointments bachi rehti hain.
- Data text (`JSON`) me save hota hai, aur padhte time wapas list me badla jata hai.
- `try/catch` = agar browser storage band kare to page crash na ho.

```js
const today = new Date().toISOString().slice(0,10);   // aaj ki date, jaise "2026-10-20"
let filter = "All", active = null, stream = null;
```
Teen "yaadasht" variables: konsa filter laga hai, konsi appointment ki call chal rahi hai, aur camera stream.

### 3.3 Chhote helper functions

```js
const $ = id => document.getElementById(id);
```
Shortcut. `$("sym")` likho, poora lamba naam nahi.

```js
function toast(m){ ... }
```
Neeche chhota message dikhata hai ("Booked...") aur 2.6 second baad hata deta hai.

```js
function view(v){
  ["home","docs","appts","room"].forEach(x => $("v-"+x).classList.toggle("hide", x !== v));
  document.querySelectorAll("#nav button").forEach(b => b.classList.toggle("on", b.dataset.v === v));
  ...
}
```
**Page badalne wala function.** Sirf wahi section dikhta hai jiska naam `v` hai; baaki par `hide` lag jata hai. Menu me bhi sirf wahi button highlight hota hai.

### 3.4 Triage screen

```js
$("go").onclick = run;
```
"Analyze" button dabate hi `run()` chalta hai.

```js
function run(){
  const txt = $("sym").value.trim();
  if (!txt) { toast("Write at least one symptom"); return }   // khali hai to roko
  const r = triage(txt);                                      // AI model chalaya
```

```js
  if (!r.found) { ... "Not enough detail" ... return }
```
Koi symptom nahi mila to batao aur General Physician suggest karo.

```js
  box.innerHTML = '<h3>Triage result</h3>' + ... +
    r.probs.map(x => '... ' + Math.round(x.p*100) + '% ... width:' + Math.round(x.p*100) + '%').join("") + ...
```
Result ka HTML banakar page par daala. Har specialty ka naam, %, aur bar (bar ki chaudai = %). Neeche button "Find <top specialty>".

```js
function pick(sp){ filter = sp; view("docs") }
```
Us button par click → filter set → Doctors page khul jata hai, sirf us specialty ke doctors ke saath.

### 3.5 Doctors aur booking

```js
function taken(id, time){
  return appts.some(a => a.docId===id && a.date===today && a.time===time && a.status!=="cancelled");
}
```
Check karta hai: **kya is doctor ka ye slot pehle se book hai** (cancelled wale ginti me nahi)? Haan/na (`true/false`) lautata hai.

```js
function renderDocs(){
  ... DOCTORS.filter(d => filter==="All" || d.sp===filter) ...
  TIMES.map(t => '<button class="slot" ' + (taken(d.id,t) ? "disabled" : "") + ' onclick="book(...)">' + t + '</button>')
```
- Filter ke hisab se doctors chune.
- Har doctor ke liye card banaya, aur har time ka button. Agar `taken()` true hai to button **disabled** (dhundhla).

```js
function book(id, time){
  if (taken(id, time)) { toast("Slot already booked"); return }   // double booking roko
  const d = DOCTORS.find(x => x.id === id);
  appts.push({ id:Date.now(), docId:id, doc:d.name, ..., status:"confirmed",
               room:"carepath-" + Math.random().toString(36).slice(2,10), notes:[] });
  save(); toast("Booked ..."); renderDocs();
}
```
- Pehle dobara check (safety).
- Nayi appointment list me jodi: unique id (`Date.now()` = abhi ka time), doctor ki details, status "confirmed".
- `room` = random naam jaise `carepath-k3j9x2ab`; yehi Jitsi video room ka naam banta hai.
- `save()` se storage me gaya, toast dikha, slots dobara draw hue (naya slot dhundhla).

### 3.6 Appointments page

```js
function cancel(id){ const a = appts.find(x => x.id===id); if (a) { a.status="cancelled"; save(); renderAppts(); ... } }
```
Appointment dhundhi, status "cancelled" kiya, save, list dobara dikhayi. Slot wapas free ho jata hai (kyunki `taken()` cancelled ko ignore karta hai).

```js
function join(id){ active = appts.find(x => x.id===id); view("room") }
```
Chuni hui appointment ko `active` banaya aur video room page khola.

### 3.7 Video consultation

```js
$("camBtn").onclick = async () => {
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video:true, audio:true });
    $("vid").srcObject = stream;
  } catch(e) { toast("Camera blocked...") }
};
```
- `getUserMedia` = **WebRTC** ka hissa; browser se camera/mic ki permission maangta hai.
- Permission mili to live stream `<video>` me chalti hai; nahi mili to message.
- `async/await` = "intezaar karo jab tak user Allow/Block na kare".

```js
$("muteBtn").onclick = () => {
  const t = stream.getAudioTracks()[0];
  t.enabled = !t.enabled;                      // true ↔ false (mute/unmute)
};
```

```js
$("jitsiBtn").onclick = () => window.open("https://meet.jit.si/" + active.room, "_blank", "noopener");
```
Naye tab me asli Jitsi video room kholta hai. Room ka naam appointment ka random `room` hai, to doctor aur patient dono isi link se judkar real call kar sakte hain.

```js
$("endBtn").onclick = () => { camera band; a.status = "completed"; save(); view("appts") };
```
Camera ke tracks `stop()` kiye, appointment "completed" ki, appointments page par wapas.

```js
$("chatIn").addEventListener("keydown", e => {
  if (e.key === "Enter" && e.target.value.trim()) { ... addMsg(...); setTimeout(() => addMsg("Doctor", "Noted..."), 700) }
});
```
Enter dabane par message chat me jata hai, aur 0.7 second baad doctor ka auto-reply aata hai (demo ke liye nakli reply).

---

## Sir ke liye "Flow" ek line me

1. `triage()` → AI (softmax scoring)
2. `renderDocs()` → doctors dikhao
3. `book()` + `taken()` → booking + double booking rokna
4. `renderAppts()` → appointments manage
5. `getUserMedia` + Jitsi → telemedicine

## Agar sir ye pooche

| Sawal | Jawab |
|---|---|
| ML kahan hai? | `triage()` me: text preprocessing, feature matching, weighted scoring, softmax probability. |
| Isko real ML kaise banayenge? | Kaggle dataset + scikit-learn (TF-IDF + Logistic Regression), model ko FastAPI se serve karke is page se `fetch()` karenge. |
| Data kahan save hota hai? | Abhi `localStorage` (browser). Aage PostgreSQL/MongoDB. |
| Video call kaise? | WebRTC (`getUserMedia`) + Jitsi Meet. |
| Limitation? | Dummy doctors, koi login nahi, rule-based model. Ye sab future scope hai. |
